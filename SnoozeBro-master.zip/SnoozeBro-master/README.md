# SnoozeBro
An alarm clock Android app for snooze-button addicts. Features will include: </br>
• An alarm lockout where the user cannot create or set a new alarm within one hour of an alarm going off</br>
• A selection of wakeup tasks, the default of which is to continuously turn off an alarm that rings at set intervals for a specified amount of time, forcing the user to stay awake and beat the impulse to go straight back to sleep
