# Alarm Clock application
It's an desktop application written in java designed to be simple to use and yet optimized in term of resources
# Features
* Shows time and date.
* Shows, Adds, updates and deletes alarms.
* each alarm can be configured to various options : days of the week, weekly, time to repeat.  
* Users can choose their own alarm ringtone
* Each alarm associated with a memo.
* contains shortcuts to some popular social media websites ( facebook, twitter, youtube and instagram )

# License 
GPL
