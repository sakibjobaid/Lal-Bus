# OpenAlarm - Android Alarm Clock App

This is a simple example for an Android App that schedules an Alarm. I included some animated icons to improve the user experience. Feel free to use the code.

![Screenshot](https://raw.githubusercontent.com/reime005/OpenAlarm/master/screen.png)

## My Blog
[mariusreimer.com](https://mariusreimer.com/)
